<?php

return array(
    'bundle:controller:name.format.engine' => __DIR__.'/../Fixtures/Resources/views/this.is.a.template.format.engine',
);
