<?php

$container->loadFromExtension('framework', array(
    'serializer' => array(
        'enabled' => true,
    ),
));
