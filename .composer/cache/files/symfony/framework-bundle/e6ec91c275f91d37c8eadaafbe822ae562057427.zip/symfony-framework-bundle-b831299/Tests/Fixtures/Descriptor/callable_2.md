
- Type: `function`
- Name: `staticMethod`
- Class: `Symfony\Bundle\FrameworkBundle\Tests\Console\Descriptor\CallableClass`
- Static: yes
