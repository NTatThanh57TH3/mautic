
- Type: `function`
- Name: `array_key_exists`
