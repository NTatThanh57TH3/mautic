<div>
    <?php echo $view['form']->widget($form) ?>
</div>
