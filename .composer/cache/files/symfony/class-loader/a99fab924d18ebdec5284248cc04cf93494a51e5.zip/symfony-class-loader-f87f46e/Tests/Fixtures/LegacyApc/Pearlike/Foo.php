<?php

class LegacyApc_Pearlike_Foo
{
    public static $loaded = true;
}
