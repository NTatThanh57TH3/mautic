<?php

class LegacyApcPrefixCollision_A_Foo
{
    public static $loaded = true;
}
