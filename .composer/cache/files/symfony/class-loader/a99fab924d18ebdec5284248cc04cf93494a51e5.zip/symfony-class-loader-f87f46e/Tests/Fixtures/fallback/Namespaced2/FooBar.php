<?php

namespace Namespaced2;

class FooBar
{
    public static $loaded = true;
}
