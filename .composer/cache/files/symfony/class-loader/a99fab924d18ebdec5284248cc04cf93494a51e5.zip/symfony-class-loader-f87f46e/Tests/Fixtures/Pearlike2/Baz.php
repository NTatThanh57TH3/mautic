<?php

class Pearlike2_Baz
{
    public static $loaded = true;
}
