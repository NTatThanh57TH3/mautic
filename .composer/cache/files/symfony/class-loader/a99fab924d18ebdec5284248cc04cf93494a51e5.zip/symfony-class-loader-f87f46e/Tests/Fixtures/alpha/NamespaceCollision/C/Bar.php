<?php

namespace NamespaceCollision\C;

class Bar
{
    public static $loaded = true;
}
