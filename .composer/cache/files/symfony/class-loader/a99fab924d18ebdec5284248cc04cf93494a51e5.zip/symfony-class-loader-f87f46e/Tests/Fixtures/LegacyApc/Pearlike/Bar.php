<?php

class LegacyApc_Pearlike_Bar
{
    public static $loaded = true;
}
