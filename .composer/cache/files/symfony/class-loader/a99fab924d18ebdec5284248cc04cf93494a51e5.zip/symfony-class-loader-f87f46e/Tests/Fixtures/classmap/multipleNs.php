<?php

namespace {
    class A
    {
    }
}

namespace Alpha {
    class A
    {
    }
    class B
    {
    }
}

namespace Beta {
    class A
    {
    }
    class B
    {
    }
}
