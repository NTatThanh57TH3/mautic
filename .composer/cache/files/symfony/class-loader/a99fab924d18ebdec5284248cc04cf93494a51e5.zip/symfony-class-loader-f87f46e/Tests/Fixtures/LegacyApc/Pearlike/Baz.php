<?php

class LegacyApc_Pearlike_Baz
{
    public static $loaded = true;
}
