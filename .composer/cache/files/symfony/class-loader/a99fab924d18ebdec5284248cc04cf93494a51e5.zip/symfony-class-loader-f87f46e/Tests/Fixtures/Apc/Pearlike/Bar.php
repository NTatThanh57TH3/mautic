<?php

class Apc_Pearlike_Bar
{
    public static $loaded = true;
}
