<?php

class LegacyApcPrefixCollision_A_Bar
{
    public static $loaded = true;
}
