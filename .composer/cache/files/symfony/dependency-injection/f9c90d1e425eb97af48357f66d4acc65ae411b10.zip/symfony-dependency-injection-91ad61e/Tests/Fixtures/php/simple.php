<?php

$container->setParameter('foo', 'foo');
