<?php
namespace PhpAmqpLib\Exception;

/**
 * @deprecated use AMQPProtocolConnectionException instead
 */
class AMQPConnectionException extends AMQPException
{
}
