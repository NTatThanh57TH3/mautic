<?php
namespace PhpAmqpLib\Exception;

class AMQPProtocolConnectionException extends AMQPProtocolException
{
}
