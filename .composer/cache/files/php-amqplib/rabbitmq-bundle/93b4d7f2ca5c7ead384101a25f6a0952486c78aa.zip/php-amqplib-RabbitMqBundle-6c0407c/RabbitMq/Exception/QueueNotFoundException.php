<?php

namespace OldSound\RabbitMqBundle\RabbitMq\Exception;

class QueueNotFoundException extends \RuntimeException
{
} 