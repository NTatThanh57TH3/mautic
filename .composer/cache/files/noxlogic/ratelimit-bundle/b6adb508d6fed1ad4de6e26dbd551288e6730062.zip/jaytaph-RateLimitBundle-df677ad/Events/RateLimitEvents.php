<?php

namespace Noxlogic\RateLimitBundle\Events;

final class RateLimitEvents
{
        const GENERATE_KEY = 'ratelimit.generate.key';
}
