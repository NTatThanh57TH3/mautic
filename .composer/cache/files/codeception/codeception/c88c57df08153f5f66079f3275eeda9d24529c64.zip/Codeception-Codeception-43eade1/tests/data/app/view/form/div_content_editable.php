<html>
<body>
    <label for="description">Description</label>
    <div contenteditable="true" name="description" id="description" cols="30" rows="10">sunrise</div>
</body>
</html>