#!/usr/bin/env php
<?php
Phar::mapPhar();

require_once 'phar://codecept.phar/autoload.php';

require_once 'phar://codecept.phar/codecept';

__HALT_COMPILER();
