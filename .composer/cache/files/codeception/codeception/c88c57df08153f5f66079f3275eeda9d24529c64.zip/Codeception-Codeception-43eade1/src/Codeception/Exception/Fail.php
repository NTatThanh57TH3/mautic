<?php
namespace Codeception\Exception;

class Fail extends \PHPUnit_Framework_AssertionFailedError
{

}
