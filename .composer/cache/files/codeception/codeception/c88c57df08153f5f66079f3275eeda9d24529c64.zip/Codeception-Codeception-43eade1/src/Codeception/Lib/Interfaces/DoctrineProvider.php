<?php
namespace Codeception\Lib\Interfaces;

interface DoctrineProvider
{
    public function _getEntityManager();
}
