# Contributing to the Joomla! Framework

Please review [http://framework.joomla.org/contribute](http://framework.joomla.org/contribute) for information on how to contribute to the Framework's development.
