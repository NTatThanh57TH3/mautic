<?php

namespace Liip\FunctionalTestBundle\Exception;

class AllowedQueriesExceededException extends \Exception
{
}
