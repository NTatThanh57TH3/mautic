<?php

namespace JMS\Serializer\Tests\Fixtures\Doctrine\SingleTableInheritance;

/**
 * Abstract base class without Entity annotation
 */
abstract class AbstractModel
{
}
