CHANGELOG for 1.0.x
===================

1.0.2 (2014-07-09)
* [Bug] Logout Request Builder #5 
* [CodeStyle] Improve code metric #7 
* [Bug] Support for formatted certificate in message XML #10 
* [Bug]  "KeyDescriptor" elment "use" attribute should be optional #12 
* [NewFeature] Support for EntitiesDescriptor element #11 
* [Bug] InResponseTo attribute optional for StatusResponse #14 #15 
* [Bug] InvalidArgumentException at LogoutRequest ->setNotOnOrAfter() #16 
* [NewFeature] New method in Signature Validator for array of keys #18 
* [NewFeature] New method EntitiesDescriptor::getByEntityId #19 
* [Bug] Fix AuthnRequest send and Response receive bidnings and url #20 
* [NewFeature] Logging of sent/received messages in Binding #23 
* [Bug] NameIDPolicy made optional in AuthnRequest? #21 
* [Bug] SignatureMethod element made optional #24 
* [Bug] StatusCode missing from status #26 
* [NewFeature] Optional constructor arguments 037a595fc
* [NewFeature] Support for IdpSsoDescriptor Attributes & NameIdFormat e37b037d1
