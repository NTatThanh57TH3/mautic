CONTRIBUTORS
============

LightSaml so far is a work result of

* Milos Tomic (tmilos)


